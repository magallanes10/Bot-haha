const { Box } = require("fca-liane-utils");

module.exports = Box;
